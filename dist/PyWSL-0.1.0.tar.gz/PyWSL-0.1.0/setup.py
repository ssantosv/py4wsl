from setuptools import setup, find_packages


setup(
    name='PyWSL',
    version='0.1.0',
    packages=find_packages(),
    url='https://github.com/mi_usuario/mi_paquete',  # Reemplaza con tu URL
    license='MIT',
    author='Sergio de los SAntos',  # Reemplaza con tu nombre
    author_email='s.delossantos@gmail.com',  # Reemplaza con tu email
    description='Descripción del paquete',
    long_description=open('README.md').read(), # Reemplaza README.md con tu archivo de descripción
    long_description_content_type='text/markdown',
    install_requires=["altgraph==0.17.4",
"certifi==2025.4.26",
"charset-normalizer==3.4.2",
"colorama==0.4.6",
"comtypes==1.4.10",
"decorator==4.4.2",
"idna==3.10",
"imageio==2.37.0",
"imageio-ffmpeg==0.6.0",
"logging==0.4.9.6",
"moviepy==1.0.3",
"numpy==2.2.5",
"packaging==24.2",
"pefile==2023.2.7",
"pillow==10.4.0",
"proglog==0.1.12",
"pyinstaller==6.12.0",
"pyinstaller-hooks-contrib==2025.2",
"pypiwin32==223",
"pystray==0.19.5",
"python-dotenv==1.1.0",
"pywin32==310",
"pywin32-ctypes==0.2.3",
"requests==2.32.3",
"six==1.17.0",
"tqdm==4.67.1",
"urllib3==2.4.0",
"watchdog==6.0.0",
"win10toast==0.9",
"windows==0.1.1"],
    python_requires='>=3.7',  # Python version
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    keywords=['WSL', 'windows subsystem for linux'],
)